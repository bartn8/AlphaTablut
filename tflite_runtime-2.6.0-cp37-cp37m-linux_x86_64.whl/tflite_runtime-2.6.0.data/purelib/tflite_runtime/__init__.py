__version__ = '2.6.0'
__git_version__ = '0.6.0-109421-g84632cb4514'
